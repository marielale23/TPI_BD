-- Funcion con valores de tabla: devuelve todos los cursos que
-- pertenecen a los roles de una empresa dada. Se usa como
-- SELECT * FROM fn_CursosDeEmpresa(@IDEmpresa).
CREATE FUNCTION fn_CursosDeEmpresa (@IDEmpresa INT)
RETURNS TABLE
AS
RETURN (
    SELECT C.IDCurso, C.nombre, C.descripcion, C.duracionhoras
    FROM Curso AS C
    INNER JOIN Roles AS R ON R.IDRol = C.IDRol
    WHERE R.IDEmpresa = @IDEmpresa
);
GO
