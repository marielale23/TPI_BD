-- Calcula automaticamente ResultadoEvaluacion.aprobado comparando
-- la nota obtenida contra el puntaje minimo de la evaluacion
-- correspondiente. Se dispara en insert y en update, y contempla
-- que "inserted" pueda traer mas de una fila.
CREATE TRIGGER tr_Aprobar
ON ResultadoEvaluacion
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE re
    SET re.aprobado = CASE WHEN re.notaObtenida >= e.puntajeMinimo THEN 1 ELSE 0 END
    FROM ResultadoEvaluacion re
    INNER JOIN inserted i ON re.IDResultado = i.IDResultado
    INNER JOIN Evaluacion e ON e.IDEvaluacion = re.IDEvaluacion;
END;
GO
