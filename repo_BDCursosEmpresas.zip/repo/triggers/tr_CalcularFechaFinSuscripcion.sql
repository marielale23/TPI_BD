-- Calcula Suscripcion.fechaFinalizacion a partir de fechaInicio
-- y la duracion del TipoSuscripcion, para que no se cargue a
-- mano y quede desincronizada si cambia el tipo o el inicio.
CREATE TRIGGER tr_CalcularFechaFinSuscripcion
ON Suscripcion
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE s
    SET s.fechaFinalizacion = DATEADD(DAY, ts.duracion, s.fechaInicio)
    FROM Suscripcion s
    INNER JOIN inserted i ON s.IDSuscripcion = i.IDSuscripcion
    INNER JOIN TipoSuscripcion ts ON ts.IDTipoSuscripcion = s.IDTipoSuscripcion;
END;
GO
